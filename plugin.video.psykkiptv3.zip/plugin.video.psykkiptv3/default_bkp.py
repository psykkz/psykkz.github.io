﻿
__scriptname__ = "Psykk IPTV3"
__author__ = "Psykk"
__scriptid__ = "plugin.video.psykkiptv3"
__version__ = "3.5.3"

import urllib, re, gzip, socket, base64, time, datetime, requests
import xbmc, xbmcplugin, xbmcgui, xbmcaddon, sys, os, random
#from resources.lib.fonctions import check, Picon, Picon_movie
from fonctions import check, Picon, Picon_movie
import xml . etree . ElementTree as ElementTree

dialog = xbmcgui.Dialog()
progress = xbmcgui.DialogProgress()
addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id=__scriptid__)

USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
agent_vlc='VLC/2.2.6 LibVLC/2.2.6'
agent_mag='Lavf53.32.100\r\n'
headers = {'User-Agent': USER_AGENT,
           'Accept': '*/*',
           'Connection': 'keep-alive'}

#U2FsdXQsIHRvaSBxdWkgbGl0IMOnYSwgamUgbWUgbW9xdWUgcXVlIHR1IHV0aWxpc2VzIG1vbiBleHRlbnNpb24gbWFpcyBhdSBtb2lucyB2aWVudCBtZSBsZSBub3RpZmllciBxdWUgamUgcHVpc3NlIGVuIGRpc2N1dGVyIGF2ZWMgdG9pLgpBIHRyw6hzIGJpZW50w7R0CihBa2FpISkKUHN5a2s=

if not(xbmc.getCondVisibility("System.HasNetwork")):
    xbmcgui.Dialog().ok('Psykkv3', "Vous n'etes pas connecte a internet ...")

socket.setdefaulttimeout(10)

listDir = addon.getSetting('ListDir')
rootDir = addon.getAddonInfo('path')
if rootDir[-1] == ';':
    rootDir = rootDir[0:-1]
rootDir = xbmc.translatePath(rootDir)


icon = xbmc.translatePath(os.path.join(rootDir, 'icon.png'))

profileDir = addon.getAddonInfo('profile')
profileDir = xbmc.translatePath(profileDir)
#.decode("utf-8")
cookiePath = os.path.join(profileDir, 'cookies.lwp')
if not os.path.exists(profileDir):
    os.makedirs(profileDir)

def getHtml(url, referer=None, hdr=None, data=None):
    s = requests.Session()
    if not hdr:
        #req = Request(url, data, headers)
        req=s.get(url, headers=headers)
    else:
        #req = Request(url, data, hdr)
        req=s.get(url, headers=hdr)
    """
    if referer:
        req.add_header('Referer', referer)
    if data:
        req.add_header('Content-Length', len(data))
    """
    #response = urlopen(req, timeout=20)
    #if response.info().get('Content-Encoding') == 'gzip':
    if 'gzip' in req.text:
        buf = StringIO( response.read())
        f = gzip.GzipFile(fileobj=buf)
        data = f.read()
        f.close()
    else:
        #data = response.read()
        data = req.read()    
    #response.close()
    return data

def addPlayLink(name, url, mode, iconimage, description,cat='' ):
    u = (sys.argv[0] +
         "?url=" + urllib.parse.quote_plus(url) +
         "&mode=" + str(mode) +
         "&name=" + urllib.parse.quote_plus(name) +
         "&description=" + urllib.parse.quote(description))
    ok = True
    liz = xbmcgui.ListItem(name)
    
    liz.setArt({'thumb': iconimage, 'icon': iconimage,'poster': iconimage,'banner': iconimage,'fanart': iconimage,'clearart': iconimage,'clearlogo': iconimage,'landscape': iconimage})
    liz.setArt({'fanart': iconimage})
    #liz.setProperty('IsPlayable', 'true')
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    video_streaminfo = {'codec': 'h264'}
    liz.addStreamInfo('video', video_streaminfo)
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=False)
    return ok

def addDir(name, url, mode, iconimage, Folder=True, description=''):
    skin_used = xbmc.getSkinDir()
    if skin_used == 'skin.estuary':
        xbmc.executebuiltin('Container.SetViewMode(500)') # "Thumbnail" view
    if url.startswith('plugin'):
        u = url
    else:
        """
        u = (sys.argv[0] +
             "?url=" + urllib.quote_plus(url) +
             "&mode=" + str(mode) +
             "&name=" + urllib.quote_plus(name) +
             "&description=" + urllib.quote_plus(description))
        """
        u = (sys.argv[0] +
             "?url=" + urllib.parse.quote(url) +
             "&mode=" + str(mode) +
             "&name=" + urllib.parse.quote(name) +
             "&description=" + urllib.parse.quote(description))
    ok = True
    liz = xbmcgui.ListItem(name)
    liz.setArt({'thumb': iconimage, 'icon': iconimage})
    fanart = os.path.join(rootDir, 'fanart.jpg')
    liz.setArt({'fanart': iconimage})
    liz.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
    ok = xbmcplugin.addDirectoryItem(handle=addon_handle, url=u, listitem=liz, isFolder=Folder)
    return ok

def GETFILTER():
    filterset = int(addon.getSetting('filterset')) + 1
    txtfilter = addon.getSetting('txtfilter' + str(filterset))
    return txtfilter

def OPENSETTINGS():
    addon.openSettings()
    xbmc.executebuiltin('Container.Refresh')


def coder(txt):
    try:
        txt=txt.decode('utf8')
    except:pass
    to_change=['\u00e9','\u00e8','\u00e0','\u2019','\u00ea','\u00e2','\u0153','\u00ee','\u00f9',
               '\u00c0','\u00e7','\u00f4','\u2026','\u00ab','\u00bb','\u00ef','\u00a0','\u00fb',
               '\u00c2','\u2013','\u00c9'
               ]
    by=['e','e','a',"'",'e','a','oe','i','u','A','c','o','!','"','"','i','','u','a','-','E']
    for j in range(len(to_change)):
        txt=txt.replace(to_change[j],by[j])
    return txt.encode('utf8')

def logg(nom='',info=''):
    pass
    fichier=open('fuckall.txt','a', errors='ignore')
    fichier.write(nom+'\n')
    fichier.write(info+'\n\n')
    fichier.close()

def run_replay(info='',msg=''):
    s = requests.Session()
    token=info.split('!')[1]
    MAC=info.split('!')[2]
    serveur=info.split('!')[3]
    nbr=info.split('!')[4]
    lien_portal=info.split('!')[5]
    try:
        duree=info.split('!')[6]
    except:pass
    
    Headers = {'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
                'Referrer': 'http://'+str(serveur)+'/c/',
                'X-User-Agent': 'Model: MAG254; Link: WiFi',
                'Authorization': 'Bearer '+str(token),
                'Cache-Control': 'no-cache',
                'Host': str(serveur),
                'Connection': 'Keep-Alive',
                'Accept-Encoding': 'gzip',
                'Cookie': 'mac='+MAC.replace(':','')+'; stb_lang=en; timezone=Europe%2FParis; adid=4b61aa25720e80fb6a377fc2560abc9e'
               }
    if 'REPLAY' in info:
        desc=''
        duree=int(duree)//24
        for j in range(duree):
            begin=datetime.datetime.fromtimestamp((time.time())-j*86400).strftime('%Y-%m-%d')
            date=datetime.datetime.fromtimestamp((time.time())-j*86400).strftime('%d-%m')
            addPlayLink(str('[COLOR green][B]--------- ▼ ')+date+str(' ▼ ---------[/COLOR][/B]'),'',3,'','')
            fifth='http://'+str(serveur)+'/' + lien_portal + '?type=epg&action=get_simple_data_table&ch_id='+str(nbr)+'&date='+str(begin)+'&p=0&JsHttpRequest=1-xml'
            r5 = s.get(fifth, headers=Headers, timeout=10)
            try:
                liste=re.findall('total_items":(.*?),"max_page_items":(.*?),',r5.text)
                nbr_pages=(int(liste[0][0])//int(liste[0][1]))+1
            except:nbr_pages=10
            liste=re.findall('{"id":"(.*?)","ch_id":"(.*?)","time":"(.*?)","time_to":"(.*?)","duration":(.*?),"name":"(.*?)","descr":"(.*?)","real_id":"(.*?)","category":"(.*?)","director":"(.*?)","actor":"","start_timestamp":(.*?),"stop_timestamp":(.*?),"t',r5.text)
            for prog in liste:
                desc=prog[6]
                ident=prog[0]
                name=coder(prog[5])
                start=prog[2].split(' ')[-1]
                addPlayLink('[COLOR gold][B]'+start+'[/COLOR][/B] - '+name, 'REPP!'+token+'!'+MAC+'!'+serveur+'!'+ident+'!'+lien_portal, 9, icon,str(desc))                
            k=1
            while k!=nbr_pages:
                k+=1
                fifth='http://'+str(serveur)+'/' + lien_portal + '?type=epg&action=get_simple_data_table&ch_id='+str(nbr)+'&date='+str(begin)+'&p='+str(k)+'&JsHttpRequest=1-xml'
                r5 = s.get(fifth, headers=Headers, timeout=10)
                liste=re.findall('{"id":"(.*?)","ch_id":"(.*?)","time":"(.*?)","time_to":"(.*?)","duration":(.*?),"name":"(.*?)","descr":"(.*?)","real_id":"(.*?)","category":"(.*?)","director":"(.*?)","actor":"","start_timestamp":(.*?),"stop_timestamp":(.*?),"t',r5.text)
                
                for prog in liste:
                    desc=prog[6]
                    ident=prog[0]
                    name=coder(prog[5])
                    start=prog[2].split(' ')[-1]
                    addPlayLink('[COLOR gold][B]'+start+'[/COLOR][/B] - '+name, 'REPP!'+token+'!'+MAC+'!'+serveur+'!'+ident+'!'+lien_portal, 9, icon,str(desc))        
            
    else:
        fifth='http://'+str(serveur)+'/' + lien_portal + '?type=tv_archive&action=create_link&cmd=auto%20/media/'+str(nbr)+'.ts&series=&forced_storage=&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml'
        r5 = s.get(fifth, headers=Headers, timeout=10)
        lien=re.findall('"cmd":"ffmpeg (.*?)","st',r5.text)[0].replace('\/','/')
        PLAY(lien+'|User-Agent=Lavf53.32.100', msg)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def run(info='',msg=''):
    s = requests.Session()
    token=info.split('!')[1]
    MAC=info.split('!')[2]
    serveur=info.split('!')[3]
    nbr=info.split('!')[4]
    lien_portal=info.split('!')[5]
    Cookies ={'mac': MAC,
                   'stb_lang':'en',
                   'timezone':'Europe%2FParis',
                   'adid':'4b61aa25720e80fb6a377fc2560abc9e'
                   }
    Headers_token = {
                    'Referer': f'http://{str(serveur)}/c/',
                    'Accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
                    'X-User-Agent': 'Model: MAG200; Link: WiFi',
                    'Authorization': f'Bearer {str(token)}',
                    'Host': f'{str(serveur)}',
                    'Connection': 'Keep-Alive',
                    'Accept-Encoding': 'gzip'
                   }
    fifth=f'http://{str(serveur)}/{lien_portal}?type=itv&action=create_link&cmd=ffmpeg%20http://localhost/ch/{str(nbr)}_&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml'
    logg('fifth',fifth)
    r5 = s.get(fifth, headers=Headers_token,  timeout=30, cookies=Cookies)
    adresse=re.findall('{"js":{"id":".*?","cmd":"ffmpeg (.*?)"},"streamer_id"',r5.text)[0].replace('\/','/')
    PLAY(adresse+'|User-Agent=Lavf53.32.100', msg)

def run_vod(info='',msg=''):
    s = requests.Session()
    token=info.split('!')[1]
    MAC=info.split('!')[2]
    serveur=info.split('!')[3]
    nbr=info.split('!')[4]
    lien_portal=info.split('!')[5]
    
    Headers_token = {
                    'Referer': f'http://{str(serveur)}/c/',
                    'Accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
                    'X-User-Agent': 'Model: MAG200; Link: WiFi',
                    'Authorization': f'Bearer {str(token)}',
                    'Host': f'{str(serveur)}',
                    'Connection': 'Keep-Alive',
                    'Accept-Encoding': 'gzip'
                   }
                    
    Cookies ={'mac': MAC,
            'stb_lang':'en',
            'timezone':'Europe%2FParis',
            'adid':'4b61aa25720e80fb6a377fc2560abc9e'
            }
                    
    fifth=f'http://{str(serveur)}/{lien_portal}?type=vod&action=create_link&cmd={str(nbr)}&series=&forced_storage=&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml'
    r5 = s.get(fifth, headers=Headers_token,  timeout=30, cookies=Cookies)
    logg(fifth,r5.text)
    adresse=re.findall('"cmd":"ffmpeg (.*?)","',r5.text)[0].replace('\/','/')
    PLAY(adresse+'|User-Agent=Lavf53.32.100', msg)

def run_serie(info='',msg=''):
    s = requests.Session()
    token=info.split('!')[1]
    MAC=info.split('!')[2]
    serveur=info.split('!')[3]
    code=info.split('!')[4]
    episode=info.split('!')[5].replace('"','')
    lien_portal=info.split('!')[6]
    
    Headers_token = {
                    'Referer': f'http://{str(serveur)}/c/',
                    'Accept': '*/*',
                    'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
                    'X-User-Agent': 'Model: MAG200; Link: WiFi',
                    'Authorization': f'Bearer {str(token)}',
                    'Host': f'{str(serveur)}',
                    'Connection': 'Keep-Alive',
                    'Accept-Encoding': 'gzip'
                   }
                    
    Cookies ={'mac': MAC,
            'stb_lang':'en',
            'timezone':'Europe%2FParis',
            'adid':'4b61aa25720e80fb6a377fc2560abc9e'
            }
    
    #fifth=f'http://{str(serveur)}/{lien_portal}?type=vod&action=create_link&cmd={code}&series={episode}&forced_storage=&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml'
    #r5 = s.get(fifth, headers=Headers_token,  timeout=30, cookies=Cookies)
    sixth=f'http://{str(serveur)}/{lien_portal}?type=vod&action=create_link&cmd={code}&series={str(episode)}&forced_storage=&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml'
    r6 = s.get(sixth, headers=Headers_token,  timeout=30, cookies=Cookies)
    #logg('R6-episode',r6.text)
    adresse=re.findall('"cmd":"ffmpeg (.*?)","',r6.text)[0].replace('\/','/')
    """
    logg('r5serie',r5.text)
    if 'play_token' in r5.text:
        adr=re.findall('ffmpeg http:\\\/\\\/(.*?)\\\/series\\\/(.*?)\\\/(.*?)\\\/(.*?)?play_token=(.*?)"',r5.text)
        for a in adr:
            adresse='http://'+a[0]+'/series/'+a[1]+'/'+a[2]+'/'+a[3]+'play_token='+a[4]
            desc=''
    else:
        adr=re.findall('ffmpeg http:\\\/\\\/(.*?)\\\/series\\\/(.*?)\\\/(.*?)\\\/(.*?)"',r5.text)
        for a in adr:
            adresse='http://'+a[0]+'/series/'+a[1]+'/'+a[2]+'/'+a[3]
            desc=''
    """
    
    PLAY(adresse+'|User-Agent=Lavf53.32.100', msg)
    
def tester_date(jour):
    mois={'january':1,
      'february':2,
      'march':3,
      'april':4,
      'may':5,
      'june':6,
      'july':7,
      'august':8,
      'september':9,
      'october':10,
      'november':11,
      'december':12}
    aujourdhui=time.time()
    jour=jour.split()
    annee=jour[2].replace(',','')
    mo=str(mois[jour[0].lower()])
    j=jour[1].replace(',','')
    date_string=f'{j}/{mo}/{annee}'
    format = "%d/%m/%Y"
    try:
        fin=datetime.datetime.strptime(date_string, format)
    except TypeError:
        fin=datetime.datetime(*(time.strptime(date_string, format)[0:6]))
    fin=time.mktime(fin.timetuple())
    #Renvoie True si fin est après aujourd'hui
    return int(fin)>int(aujourdhui)

def MAIN(url=''):

    ###VERIFIER SI DES SERVEURS SONT PRESENTS DANS LES PARAMETRES:
    
    serveur1 = addon.getSetting('serveur1')
    mac1 = addon.getSetting('mac1')
    serveur2 = addon.getSetting('serveur2')
    mac2 = addon.getSetting('mac2')
    if serveur1!='' and mac1!='':
        addDir(serveur1+' '+mac1, 'init!'+serveur1+'!'+mac1+'!9!9', 1000, icon, Folder=True, description='')
    if serveur2!='' and mac2!='':
        addDir(serveur2+' '+mac2, 'init!'+serveur2+'!'+mac2+'!9!9', 1000, icon, Folder=True, description='')

    #liste=requests.get('https://www.dropbox.com/s/rz7fyei2xrer709/iptv_serveurs_3.5.csv?raw=1')
    liste=requests.get('https://www.dropbox.com/s/juqniojt0u853l4/iptv_serveurs_3.5_test.csv?raw=1')
    liste=liste.text.split('\n')
    liste.sort()
    for serveur in liste:
        if serveur!='':
            #FORMAT :
            #Ordre	Nom	Url Serveur	Url Macs	Url logo	Mode Kodi check compte	Mode kodi parcours
            #101	Prime+	dream-ott.com	https://www.dropbox.com/s/stpdzpld0yjjqrg/Mac_primeplus.tv%218080.txt?raw=1	https://www.dropbox.com/s/yxfnbuemn6jvhle/IPTV_prime.png?raw=1		
            nom=serveur.split(';')[1].replace('\n','')
            serv=serveur.split(';')[2].replace('\n','')
            dropfile=serveur.split(';')[3].replace('\n','')
            dropfile_logo=serveur.split(';')[4].replace('\n','')
            mode_login=serveur.split(';')[5].replace('\n','')
            mode_parcours=serveur.split(';')[6].replace('\n','')
            
            if '#' not in serveur and '&' not in serveur and '$' not in serveur and len(serveur)>10:
                addDir(nom, 'init!'+serv+'!'+dropfile+'!'+mode_login+'!'+mode_parcours, 1000, dropfile_logo, Folder=True, description='')
                #logg(nom,serv)
    #addDir('Platinium', 'init!217.182.65.218:89/stalker_portal!00%3A01%3A79%3A38%3A64%3A44!8!1', 1000, icon, Folder=True, description='')
    skin_used = xbmc.getSkinDir()
    if skin_used == 'skin.estuary':
        xbmc.executebuiltin('Container.SetViewMode(500)') # "Thumbnail" view
    xbmcplugin.endOfDirectory(int(sys.argv[1]))

def emu_mag(info='',msg=''):
    xxx = addon.getSetting('xxx')
    epg = addon.getSetting('epg')
    #portal='portal.php'
    portal='server/load.php'
    s = requests.Session()
    if 'init' in info:
        ok=0
        #info : 'init!'+serv+'!'+dropfile+'!'+mode_login+'!'+mode_parcours
        serveur=info.split('!')[1]
        lien=info.split('!')[2]
        mode_login=info.split('!')[3]
        mode_parcours=info.split('!')[4]
        if str(mode_login)=='1' or str(mode_login)=='2' or str(mode_login)=='3':
            ##Check if ban
            #portal='http://'+str(serveur)+'/c'
            version=f'http://{str(serveur)}/c/version.js'
            try:
                headers = {'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                            'Accept-Encoding': 'gzip, deflate',
                            'Accept-Language': 'fr-FR,fr;q=0.9,en-US;q=0.8,en;q=0.7',
                            'Cache-Control': 'no-cache',
                            'Connection': 'keep-alive',
                            'Cookie': 'mac=; stb_lang=undefined; timezone=undefined; adid=',
                            'DNT': '1',
                            'Host': f'{str(serveur)}',
                            'Pragma': 'no-cache',
                            'Upgrade-Insecure-Requests': '1',
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 OPR/68.0.3618.191'
                           }
                           
                r=s.get(version, headers=headers)
                r=r.text
                logg(version,r)
            except:
                r=''
            if 'var ver' not in r:
                xbmcgui.Dialog().ok('Erreur acces Portail', 'Aie, il semblerait que votre IP ou le host soit bannie par votre FAI , essayez un VPN')
                1/0
            else:
                #On recupere toutes les macs:
                macs=urllib.request.urlopen(lien).readlines()
                while ok<15:
                    ok+=1
                    #On en prend une MAC au hasard
                    #Format : 00%3A1A%3A79%3AC2%3A49%3A5D:a | SERVEUR = panel.globepremium.com:8080 | DATE_EXPIRE = March 27, 2022, 6:02 pm | MAC = 00:1A:79:C2:49:5D | NEWHOST = panel.globesrv.com:80
                    #MAC=macs[random.randrange(len(macs))].decode().split(':')[0].replace('\n','').replace('\r','')
                    try:
                        choix=random.choice(macs).decode().split('|')
                        MAC=choix[0].split(':')[0]
                        jour=choix[2].replace('\n','').replace('\r','').replace(' DATE_EXPIRE = ','')
                        if 'unlimited' not in jour.lower():
                            if tester_date(jour)==False:
                                1/0
                        if len(MAC)<2:
                            1/0
                        logg(str(serveur),MAC)
                        Headers_mac = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/53.0.2785.116 Safari/537.36',
                                    'Referrer': f'http://{str(serveur)}/c/',
                                    'X-User-Agent': 'Model: MAG254; Link: WiFi',
                                    'Cache-Control': 'no-cache',
                                    'Host': f'{str(serveur)}',
                                    'Connection': 'Keep-Alive',
                                    'Accept-Encoding': 'gzip',
                                    'Cookie': f'mac={MAC}; stb_lang=en; timezone=Europe%2FParis; adid=cd66d3fa250b54a80dd7c54fd21b014f'}
                        """
                        Headers = {'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
                                'Referrer': f'http://{str(serveur)}/c/',
                                'X-User-Agent': 'Model: MAG254; Link: WiFi',
                                'Cache-Control': 'no-cache',
                                'Host': f'{str(serveur)}',
                                'Connection': 'Keep-Alive',
                                'Accept-Encoding': 'gzip'
                               }
                        """
                        Headers1={ 'Host': f'{str(serveur)}',
                                    'Accept': 'image/webp,/;q=0.8',
                                    'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
                                    'Connection': 'Keep-Alive',
                                    'Accept-Encoding': 'gzip',
                                    'Cookie': f'mac={str(MAC)}'
                                   }
                        
                        #On verifie si Ok suivant le mode_login :
                        if str(mode_login) == '1':
                            first=f'http://{str(serveur)}/{portal}?type=stb&action=get_modules&JsHttpRequest=1-xml'
                            r1 = s.post(first, headers=Headers1, timeout=20)
                            logg('first',r1.text)
                            if str(r1.status_code)!='200':
                                1/0
                            if '{"js":' in str(r1.text):
                                1/0
                        elif str(mode_login) == '3':
                            first=f'http://{str(serveur)}/{portal}?type=stb&action=get_modules&JsHttpRequest=1-xml'
                            r1 = s.post(first, headers=Headers1, timeout=20)
                            logg('first',r1.text)
                            if str(r1.status_code)!='200':
                                1/0
                            if '{"js":' not in str(r1.text):
                                1/0
                                
                        #On recupère le token:
                        second=f'http://{str(serveur)}/{portal}?type=stb&action=handshake&token=&prehash=false&JsHttpRequest=1-xml'
                        r2 = s.post(second, headers=Headers_mac, timeout=20)
                        logg('token',r2.text)
                        token=re.findall('"token":".+"}}', r2.text)[0].replace('"token":"','').replace('"}}','')
                        Headers_token = {
                                'Referer': f'http://{str(serveur)}/c/',
                                'Accept': '*/*',
                                'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
                                'X-User-Agent': 'Model: MAG200; Link: WiFi',
                                'Authorization': f'Bearer {str(token)}',
                                'Host': f'{str(serveur)}',
                                'Connection': 'Keep-Alive',
                                'Accept-Encoding': 'gzip'
                               }
                        
                        Cookies ={'mac': MAC,
                                   'stb_lang':'en',
                                   'timezone':'Europe%2FParis',
                                   'adid':'4b61aa25720e80fb6a377fc2560abc9e'
                                   }
                        troisieme=f'http://{str(serveur)}/{portal}?type=stb&action=get_modules&JsHttpRequest=1-xml'
                        r3 = s.get(troisieme, headers=Headers_token, timeout=20, cookies=Cookies)
                        ok=1000
                    except:
                        pass
   
    else:
        token=info.split('!')[1]
        MAC=info.split('!')[2]
        serveur=info.split('!')[3]
        mode_parcours=info.split('!')[4].replace('\n','')
        
        Cookies ={'mac': MAC,
                   'stb_lang':'en',
                   'timezone':'Europe%2FParis',
                   'adid':'4b61aa25720e80fb6a377fc2560abc9e'
                   }
        Headers_token = {
                        'Referer': f'http://{str(serveur)}/c/',
                        'Accept': '*/*',
                        'User-Agent': 'Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3',
                        'X-User-Agent': 'Model: MAG200; Link: WiFi',
                        'Authorization': f'Bearer {str(token)}',
                        'Host': f'{str(serveur)}',
                        'Connection': 'Keep-Alive',
                        'Accept-Encoding': 'gzip'
                       }
    if 'ITV' in info:
        try:
            ident_pays=info.split('!')[5].replace('id":"','').replace('"','')
        except:
            ident_pays=None
        if ident_pays==None:
            ###
            xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )
            xbmc.executebuiltin('Container.SetViewMode(51)') # "Poster" view
            ###
            portal='portal.php'
            third=f'http://{str(serveur)}/{portal}?type=itv&action=get_genres&JsHttpRequest=1-xml'
            r3 = s.get(third, headers=Headers_token, cookies=Cookies)
            logg('r3',r3.text)
            categories=re.findall('{"id":"(.*?)","title":"(.*?)","',r3.text)
            
            for cat in categories:
                try:
                    ids=cat[0]
                    noms=cat[1]
                    try:
                        picon=Picon(rootDir,noms)
                    except:
                        picon=icon
                    if ids!=[] and ids!="*":
                        if 'adult' in noms.lower() or 'xxx' in noms.lower():
                            if xxx == 'true':
                                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Attention",'Chaines adultes actives', 9900, picon))
                                addDir(noms, f'ITV!{token}!{MAC}!{serveur}!{mode_parcours}!{ids}', 4, picon, Folder=True, description='')
                        else:
                            addDir(noms, f'ITV!{token}!{MAC}!{serveur}!{mode_parcours}!{ids}', 4, picon, Folder=True, description='')
                except:pass
            
            ####
            xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )
            xbmc.executebuiltin('Container.SetViewMode(51)') # "Poster" view
            ####
        else:
            ####
            if addon.getSetting('liste')=='true':
                xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )
                xbmc.executebuiltin('Container.SetViewMode(50)') # "Poster" view
            else:
                xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )
                xbmc.executebuiltin('Container.SetViewMode(51)') # "Poster" view
            
            if '1' in str(mode_parcours):
                k=0
                #On verifie le format des chaines
                forth=f'http://{str(serveur)}/{portal}?type=itv&action=get_ordered_list&genre={str(ident_pays)}&force_ch_link_check=&fav=0&sortby=number&hd=0&p='+str(k)+'&JsHttpRequest=1-xml'
                r4 = s.post(forth, headers=Headers_token,  timeout=10, cookies=Cookies)
                k=re.findall('"js":{"total_items":(.*?),"max_page_items":(.*?),',r4.text)
                nbr_pages=int(k[0][0])//int(k[0][1])
                
                """ PARTIE A RETRAVAILLER POUR L'EPG
                #On recupere un ident de chaine fonctionnel:
                c=re.findall('"id":"(.*?)","name":"(.*?)",".*?"cmd":"(.*?)",".*?,"logo":"(.*?)","',r4.text)
                ident_chaine=c[0][0]
                
                #On récupere le user:pass
                cinquieme=f'http://{str(serveur)}/{portal}?type=itv&action=create_link&cmd=ffmpeg%20http://localhost/ch/{str(ident_chaine)}_&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml'
                r5 = s.get(cinquieme, headers=Headers_token,  timeout=30, cookies=Cookies)
                adresse=re.findall('{"js":{"id":".*?","cmd":"ffmpeg (.*?)"},"streamer_id"',r5.text)[0].replace('\/','/')
                #http://panel.globesrv.com:80/y44d9O4vm6/YQ1HrCcUW4/6305?play_token=ToSRQa9Zty
                user=adresse.split('/')[-3]
                pwd=adresse.split('/')[-2]
                url_epg=f'http://{str(serveur)}/xmltv.php?username={user}&password={pwd}'
                r_epg = s.get(url_epg, headers=Headers_token,  timeout=30, cookies=Cookies)
                logg('epg',r_epg.text)
                
                #On charge la page enigma2 pour trouver l'epg
                url_epg=f'http://{str(serveur)}/enigma2.php?username={user}&password={pwd}&type=get_live_streams&cat_id={ident_pays}'
                r_epg = s.get(url_epg, headers=Headers_token,  timeout=30, cookies=Cookies)
                epg_chaines=re.findall('<channel><title>(.*?)<\/title>.*?<desc_image><!\[CDATA\[(.*?)]]><\/desc_image>.*?<stream_url><!\[CDATA\[(.*?)]]><\/stream_url>',r_epg.text)
                logg('epg',str(epg_chaines))
                for c in epg_chaines:
                    ident_chaine=c[2].split('/')[-1].replace('.ts','')
                    epg=base64.b64decode(chaine[0]).split('[')[-1].replace(']')
                """
                
                for k in range(1,int(nbr_pages)+2):
                    forth=f'http://{str(serveur)}/{portal}?type=itv&action=get_ordered_list&genre={str(ident_pays)}&force_ch_link_check=&fav=0&sortby=number&hd=0&p='+str(k)+'&JsHttpRequest=1-xml'
                    r4 = s.post(forth, headers=Headers_token,  timeout=10, cookies=Cookies)
                    chaines=re.findall('"id":"(.*?)","name":"(.*?)",".*?"cmd":"(.*?)",".*?,"logo":"(.*?)","',r4.text)
                    
                    for chaine in chaines:
                        ida=chaine[0]
                        nom=chaine[1].encode().decode('unicode_escape')
                        lien=chaine[2].split('/')[-1].replace('_','')
                        logo=chaine[3]
                        desc=''
                        addPlayLink(coder(nom), f'ITV!{token}!{MAC}!{serveur}!{lien}!{portal}', 6, logo.replace('\\','').replace('\/','/'),str(desc),str(token+'ZZZ'+MAC+'ZZZ'+serveur+'ZZZ'+ida))

            """PARTIE A REVOIR POUR PASSER PAR ENIGMA2

            if '2' in str(mode_parcours):
                #METHODE ENIGMA2
                #On cherche une chaine valide
                k=0
                quatrieme=f'http://{str(serveur)}/{portal}?type=itv&action=get_ordered_list&genre={str(ident_pays)}&force_ch_link_check=&fav=0&sortby=number&hd=0&p='+str(k)+'&JsHttpRequest=1-xml'
                r4 = s.post(quatrieme, headers=Headers_token,  timeout=10, cookies=Cookies)
                chaines=re.findall('"id":"(.*?)","name":"(.*?)",".*?"cmd":"(.*?)",".*?,"logo":"(.*?)","',r4.text)
                ident_chaine=chaines[0][0]
                #On récupere le user:pass
                cinquieme=f'http://{str(serveur)}/{portal}?type=itv&action=create_link&cmd=ffmpeg%20http://localhost/ch/{str(ident_chaine)}_&series=&forced_storage=0&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml'
                #logg('cinquieme',cinquieme)
                r5 = s.get(cinquieme, headers=Headers_token,  timeout=30, cookies=Cookies)
                adresse=re.findall('{"js":{"id":".*?","cmd":"ffmpeg (.*?)"},"streamer_id"',r5.text)[0].replace('\/','/')
                #http://panel.globesrv.com:80/y44d9O4vm6/YQ1HrCcUW4/6305?play_token=ToSRQa9Zty
                user=adresse.split('/')[-3]
                pwd=adresse.split('/')[-2]
                #On charge la liste au format enigma2
                sixieme=f'http://{str(serveur)}/enigma2.php?username={user}&password={pwd}&type=get_live_streams&cat_id={ident_pays}'
                r6 = s.get(sixieme, headers=Headers_token,  timeout=30, cookies=Cookies)
                #logg('sixieme',r6.text)
                chaines=re.findall('<channel><title>(.*?)<\/title>.*?<desc_image><!\[CDATA\[(.*?)]]><\/desc_image>.*?<stream_url><!\[CDATA\[(.*?)]]><\/stream_url>',r6.text)
                for chaine in chaines:
                    #ida=chaine[0]
                    nom=base64.b64decode(chaine[0])
                    #nom=chaine[0].decode('base64')
                    #lien=chaine[2].split('/')[-1].replace('_','')
                    logo=chaine[1]
                    lien=chaine[2]
                    logg(str(nom),logo+'\n'+lien)
                    desc=''
                    ida='|User-Agent=Lavf53.32.100'
                    addPlayLink(coder(nom), f'{lien}|User-Agent=Lavf53.32.100', 3, logo.replace('\\','').replace('\/','/'),str(desc),'')
            """
            ####
            if addon.getSetting('liste')=='true':
                xbmcplugin.setContent( int(sys.argv[1]) ,"files" )
                xbmc.executebuiltin('Container.SetViewMode(50)')
            else:
                xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )
                xbmc.executebuiltin('Container.SetViewMode(51)') # "Poster" view
            ####
    elif 'VOD' in info:
        try:
            ident_vod=info.split('!')[5].replace('id":"','').replace('"','')
        except:
            ident_vod=None
        if ident_vod==None:
            third=f'http://{str(serveur)}/{portal}?type=vod&action=get_categories&JsHttpRequest=1-xml'
            r3 = s.get(third, headers=Headers_token,  timeout=30, cookies=Cookies)
            categories=re.findall('{"id":"(.*?)","title":"(.*?)","alias"',r3.text)
            for cat in categories:
                nom=cat[1].encode().decode('unicode_escape')
                ids=cat[0]
                try:
                    picon=Picon(noms)
                except:
                    picon=icon
                if 'adult' in nom.lower() or 'xxx' in nom.lower():
                    if xxx == 'true':
                        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Attention",'Chaines adultes actives', 9900, picon))
                        addDir(coder(nom), f'VOD!{token}!{MAC}!{serveur}!{portal}!{str(ids)}', 4, picon, Folder=True, description='')
                else:
                    addDir(coder(nom), f'VOD!{token}!{MAC}!{serveur}!{portal}!{str(ids)}', 4, picon, Folder=True, description='')

            ###
            xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )
            xbmc.executebuiltin('Container.SetViewMode(51)') # "Poster" view
            ###

        else:
            k=0
            #On cherche le nombre de pages
            forth=f'http://{str(serveur)}/{portal}?type=vod&action=get_ordered_list&movie_id=0&season_id=0&episode_id=0&category={str(ident_vod)}&fav=0&sortby=added&hd=0&not_ended=0&p='+str(k+1)+'&JsHttpRequest=1-xml'
            r4 = s.post(forth, headers=Headers_token,  timeout=10, cookies=Cookies)
            k=re.findall('"js":{"total_items":(.*?),"max_page_items":(.*?),',r4.text)
            nbr_pages=int(k[0][0])//int(k[0][1])
            
            for k in range(1,int(nbr_pages)+2):
                forth=f'http://{str(serveur)}/{portal}?type=vod&action=get_ordered_list&movie_id=0&season_id=0&episode_id=0&category={str(ident_vod)}&fav=0&sortby=added&hd=0&not_ended=0&p={str(k)}&JsHttpRequest=1-xml'
                r4 = s.get(forth, headers=Headers_token,  timeout=10, cookies=Cookies)
                films=re.findall('{"id":"(.*?)","owner".*?"name":"(.*?)",".*?"description":"(.*?)",".*?"actors":"(.*?)".*?"year":"(.*?)",".*?"screenshot_uri":"(.*?)",".*?"cmd":"(.*?)","',r4.text)
                for film in films:
                    ids=film[0]
                    try:
                        nom=film[1].encode().decode('unicode_escape')
                    except:
                        nom=film[1]
                    try:
                        desc=film[2].encode().decode('unicode_escape')
                    except:
                        desc=film[2]
                    try:
                        desc+='\nActeurs : '+film[3].encode().decode('unicode_escape')
                    except:
                        desc+='\nActeurs : '+film[3]
                    try:
                        desc+='\nDate sortie : '+film[4].encode().decode('unicode_escape')
                    except:
                        desc+='\nDate sortie : '+film[4]
                    logo=film[5].replace('\/','/')
                    cmd=film[6]
                    if 'adult' in nom.lower() or 'xxx' in nom.lower():
                        if xxx == 'true':
                            xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Attention",'Chaines adultes actives', 9900, picon))
                            addPlayLink(coder(nom), f'VOD!{token}!{MAC}!{serveur}!{cmd}!{portal}', 7, logo,coder(desc))
                    else:
                        addPlayLink(nom, f'VOD!{token}!{MAC}!{serveur}!{cmd}!{portal}', 7, logo,desc)

            ###
            xbmcplugin.setContent( int(sys.argv[1]) ,"movies" )
            xbmc.executebuiltin('Container.SetViewMode(51)') # "Poster" view
            ###
            
    elif 'SERIES' in info:
        try:
            ident_serie=info.split('!')[5].replace('id":"','').replace('"','')
        except:
            ident_serie=None
        if ident_serie==None:
            third=f'http://{str(serveur)}/{portal}?type=series&action=get_categories&JsHttpRequest=1-xml'
            r3 = s.get(third, headers=Headers_token,  timeout=20, cookies=Cookies)
            categories=re.findall('{"id":"(.*?)","title":"(.*?)","alias"',r3.text)
            for cat in categories:
                nom=cat[1].encode().decode('unicode_escape')
                ids=cat[0]
                try:
                    picon=Picon(noms)
                except:
                    picon=icon
                if 'adult' in nom.lower() or 'xxx' in nom.lower():
                    if xxx == 'true':
                        xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Attention",'Chaines adultes actives', 9900, picon))
                        addDir(coder(nom), f'SERIES!{token}!{MAC}!{serveur}!{portal}!{str(ids)}', 4, picon, Folder=True, description='')
                else:
                    addDir(coder(nom), f'SERIES!{token}!{MAC}!{serveur}!{portal}!{str(ids)}', 4, picon, Folder=True, description='')
            ###
            xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )
            xbmc.executebuiltin('Container.SetViewMode(53)') # "Poster" view
            ###
            
        else:
            try:
                saison=info.split('!')[6].replace('id":"','').replace('"','')
            except:
                saison=None
            if saison==None:
                k=0
                forth=f'http://{str(serveur)}/{portal}?type=series&action=get_ordered_list&movie_id=0&season_id=0&episode_id=0&category={str(ident_serie)}&fav=0&sortby=added&hd=0&not_ended=0&p={str(k)}&JsHttpRequest=1-xml'
                r4 = s.post(forth, headers=Headers_token,  timeout=10, cookies=Cookies)
                k=re.findall('"js":{"total_items":(.*?),"max_page_items":(.*?),',r4.text)
                nbr_pages=int(k[0][0])//int(k[0][1])
                for k in range(1,int(nbr_pages)+2):
                    forth=f'http://{str(serveur)}/{portal}?type=series&action=get_ordered_list&movie_id=0&season_id=0&episode_id=0&category={str(ident_serie)}&fav=0&sortby=added&hd=0&not_ended=0&p={str(k)}&JsHttpRequest=1-xml'
                    r4 = s.post(forth, headers=Headers_token,  timeout=10, cookies=Cookies)
                    series=re.findall('{"id":"(.*?)","owner".*?"name":"(.*?)",".*?"description":"(.*?)",".*?"actors":"(.*?)".*?"year":"(.*?)",".*?"screenshot_uri":"(.*?)",".*?"cmd":"(.*?)","',r4.text)
                    for serie in series:
                        ids=serie[0]
                        try:
                            nom=serie[1].encode('latin-1').decode('unicode_escape')
                        except:
                            nom=serie[1]
                        try:
                            desc=serie[2].encode('latin-1').decode('unicode_escape')
                        except:
                            desc=serie[2]
                        #act=serie[3].encode('latin1').decode('utf8')
                        try:
                            act=serie[3].encode('latin-1').decode('unicode_escape')
                            desc+=f"\nActeurs : {act}"
                        except:
                            desc+=f"\nActeurs : {serie[3]}"
                        #.decode('unicode_escape')
                        try:
                            desc+='\nDate sortie : '+serie[4].encode('latin-1').decode('unicode_escape').replace('\\','')
                        except:
                            desc+='\nDate sortie : '+serie[4]
                        logo=serie[5].replace('\/','/')
                        cmd=serie[6]
                        if 'adult' in nom.lower() or 'xxx' in nom.lower():
                            if xxx == 'true':
                                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Attention",'Chaines adultes actives', 9900, picon))
                                #addPlayLink(coder(nom), f'SERIES!{token}!{MAC}!{serveur}!{portal}!{ident_serie}!{ids}', 4, logo,coder(desc))
                                addDir(nom, f'SERIES!{token}!{MAC}!{serveur}!{portal}!{ident_serie}!{ids}', 4, logo, Folder=True, description=coder(desc))
                        else:
                            addDir(nom, f'SERIES!{token}!{MAC}!{serveur}!{portal}!{ident_serie}!{ids}', 4, logo, Folder=True, description=coder(desc))
                            #addPlayLink(coder(nom), f'SERIES!{token}!{MAC}!{serveur}!{portal}!{ident_serie}!{ids}', 4, logo,coder(desc))
                
                ###
                xbmcplugin.setContent( int(sys.argv[1]) ,"movies" )
                xbmc.executebuiltin('Container.SetViewMode(51)') # "Poster" view
                ###
                
            else:
                fifth=f'http://{str(serveur)}/{portal}?type=series&action=get_ordered_list&movie_id={str(saison)}&season_id=0&episode_id=0&category={str(ident_serie)}&fav=0&sortby=added&hd=0&not_ended=0&p=1&JsHttpRequest=1-xml'
                r5 = s.post(fifth, headers=Headers_token,  timeout=10, cookies=Cookies)
                #logg('saisons',r5.text)
                saisons=re.findall('{"id":"(.*?)","owner".*?"name":"(.*?)",".*?"description":"(.*?)",".*?"series":(.*?),".*?"actors":"(.*?)".*?"year":"(.*?)",".*?"screenshot_uri":"(.*?)",".*?"cmd":"(.*?)","',r5.text)
                
                for sais in saisons:
                    ids=sais[0]
                    desc=sais[2].encode().decode('unicode_escape')
                    logo=sais[6].replace('\/','/')
                    code=sais[7]
                    
                    for episode in sais[3].split(','):
                        episode=episode.replace('[','').replace(']','')
                        #sixth=f'http://{str(serveur)}/{portal}?type=series&action=create_link&cmd={code}&series=&forced_storage=&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml'
                        #sixth=f'http://{str(serveur)}/{portal}?type=vod&action=create_link&cmd={code}&series={str(episode)}&forced_storage=&disable_ad=0&download=0&force_ch_link_check=0&JsHttpRequest=1-xml'
                        #sixth=f'http://{str(serveur)}/{portal}?type=series&action=get_ordered_list&movie_id={str(saison)}&season_id={str(saison)}:1&episode_id=0&category={str(ident_serie)}&fav=0&sortby=added&hd=0&not_ended=0&p=1&JsHttpRequest=1-xml'
                        #r6 = s.post(sixth, headers=Headers_token,  timeout=10, cookies=Cookies)
                        #addDir(f'{sais[1]} - Episode{episode}', f'SERIES!{token}!{MAC}!{serveur}!{code}!{episode}!{portal}', 8, logo, Folder=False, description='')
                        addPlayLink(f'{sais[1]} - Episode{episode}', f'SERIES!{token}!{MAC}!{serveur}!{code}!{episode}!{portal}', 8, logo,coder(desc))
                    
                ###
                xbmcplugin.setContent( int(sys.argv[1]) ,"movies" )
                xbmc.executebuiltin('Container.SetViewMode(53)') # "Poster" view
                ###
                #xbmcplugin.endOfDirectory(int(sys.argv[1]))
    elif 'RADIOS' in info:
        nbr_pages=20
        k=0        
        while k!=nbr_pages:

                forth='http://'+str(serveur)+'/' + lien_portal + '?type=radio&action=get_ordered_list&all=0&p='+str(k+1)+'&JsHttpRequest=1-xml'
                k+=1
                r4 = s.get(forth, headers=Headers, timeout=10)
                
                nbr_pages=int(int(re.search('total_items":(.*?),', str(r4.text)).group(1))/int(re.search('"max_page_items":(.*?),', str(r4.text)).group(1)))+1
                a_etudier=r4.text.split('{')
                for chaine in a_etudier:
                    try:
                        name=re.search('"name":"(.*?)"',str(chaine))
                        if name!=None:
                            name=coder(name.group(1))
                            cmd=re.search('"cmd":"(.*?)"',str(chaine))
                            if cmd!=None: cmd=(cmd.group(1))
                            if 'localhost' in cmd:
                                addPlayLink(str(name), 'RADIOS!'+token+'!'+MAC+'!'+serveur+'!'+str(cmd).replace('ffmpeg http:\\/\\/localhost\\/ch\\/','').replace('_',''), 6, icon,'')
                            else:
                                addPlayLink(str(name), str(cmd).replace('ffmpeg ','').replace('\/','/')+'|User-Agent=Lavf53.32.100', 3, icon,'')
                    except:pass
    elif 'REPLAY' in info:
        try:
            ident=info.split('!')[5].replace('id":"','').replace('"','')
        except:
            ident=None
        if ident==None:
            ###
            xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )
            xbmc.executebuiltin('Container.SetViewMode(51)') # "Poster" view
            ###
            
            third='http://'+str(serveur)+'/' + lien_portal + '?type=itv&action=get_genres&JsHttpRequest=1-xml'
            r3 = s.get(third, headers=Headers, timeout=20)
            
            ids=re.findall('"id":"\d+"',r3.text)
            noms=re.findall('"title":"(.*?)"',r3.text)
            categories=r3.text.split('{"i')
            for cat in categories:
                try:
                    ids=re.findall('d":"\d+"',cat)
                    noms=re.findall('"title":"(.*?)"',cat)
                    try:
                        picon=Picon(rootDir,noms[0])
                    except:
                        picon=icon
                    if ids[0]!=[] and ids[0]!=[u'All']:
                        if 'adult' in noms[0].lower() or 'xxx' in noms[0].lower():
                            if xxx == 'true':
                                xbmc.executebuiltin('Notification(%s, %s, %d, %s)'%("Attention",'Chaines adultes actives', 9900, picon))
                                addDir(noms[0], 'REPLAY!'+token+'!'+MAC+'!'+serveur+'!'+lien_portal+'!'+str(ids[0].replace('d":"','').replace('"','')), 4, picon, Folder=True, description='')
                        else:
                            addDir(noms[0], 'REPLAY!'+token+'!'+MAC+'!'+serveur+'!'+lien_portal+'!'+str(ids[0].replace('d":"','').replace('"','')), 4, picon, Folder=True, description='')
                except:pass
            ####
            xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )
            xbmc.executebuiltin('Container.SetViewMode(51)') # "Poster" view
            ####
        else:
            ####
            xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )
            xbmc.executebuiltin('Container.SetViewMode(51)') # "Poster" view
            ####
            try:
                epg='http://'+str(serveur)+'/' + lien_portal + '?type=itv&action=get_ordered_list&genre=1&force_ch_link_check=&fav=0&sortby=number&hd=0&p=0&JsHttpRequest=1-xml'
                repg = s.get(epg, headers=Headers, timeout=10)
                liste=re.findall('total_items":(.*?),"max_page_items":(.*?),',repg.text)
                nbr_pages=(int(liste[0][0])//int(liste[0][1]))+1
                if nbr_pages<3:nbr_pages=30
            except:nbr_pages=30
            
            k=0
            
            while k!=nbr_pages:
                k+=1
                if True:
                #try:
                    epg='http://'+str(serveur)+'/' + lien_portal + '?type=itv&action=get_ordered_list&genre='+str(ident)+'&force_ch_link_check=&fav=0&sortby=number&hd=0&p='+str(k)+'&JsHttpRequest=1-xml'
                    repg = s.get(epg, headers=Headers, timeout=10)
                    a_etudier=re.findall('{"id":"(.*?)","name":"(.*?)","number":"(.*?)","censored":"(.*?)","cmd":"(.*?)","cost":"(.*?)","enable_tv_archive":(.*?),"wowza_tmp(.*?)"logo":"(.*?)","correct_time":"(.*?)","tv_archive_duration":(.*?),"locked":(.*?),"cmds":\[{"id"(.*?)},',repg.text)
                    
                    
                    for chaine in a_etudier:
                        if chaine[6]=='1':
                            ida=chaine[0]
                            name=chaine[1]
                            cmd=chaine[4]
                            try:
                                logo=chaine[8]
                            except:logo=icon
                            desc=''
                            if 'localhost' in cmd:
                                addDir(name, 'REPLAY!'+token+'!'+MAC+'!'+serveur+'!'+cmd.replace('ffmpeg http:\\/\\/localhost\\/ch\\/','').replace('_','')+'!'+lien_portal+'!'+chaine[10], 9, logo.replace('\\',''),True,str(desc))
                            else:
                                cmd=cmd.split('\/')[-1].replace('.ts','')
                                addDir(name, 'REPLAY!'+token+'!'+MAC+'!'+serveur+'!'+cmd+'!'+lien_portal+'!'+chaine[10], 9, logo.replace('\\',''),True,str(desc))
            ####
            xbmcplugin.setContent( int(sys.argv[1]) ,"episodes" )
            xbmc.executebuiltin('Container.SetViewMode(51)') # "Poster" view
            ####

    else:
        addDir('TV',f'ITV!{token}!{MAC}!{serveur}!{mode_parcours}', 4, xbmc.translatePath(os.path.join(rootDir, 'resources','images','fournisseurs','iptv_live.png')))
        addDir('VOD',f'VOD!{token}!{MAC}!{serveur}!{mode_parcours}', 4, xbmc.translatePath(os.path.join(rootDir, 'resources','images','fournisseurs','iptv_vod.png')))
        addDir('SERIES',f'SERIES!{token}!{MAC}!{serveur}!{mode_parcours}', 4, xbmc.translatePath(os.path.join(rootDir, 'resources','images','fournisseurs','iptv_series.png')))
        #addDir('RADIOS',f'RADIOS!{token}!{MAC}!{serveur}!{mode_parcours}', 4, xbmc.translatePath(os.path.join(rootDir, 'resources','images','fournisseurs','iptv_radio.png')))
        #addDir('REPLAY',f'RREPLAY!!{token}!{MAC}!{serveur}!{mode_parcours}', 4, xbmc.translatePath(os.path.join(rootDir, 'resources','images','fournisseurs','IPTV_Replay.png')))
    xbmcplugin.endOfDirectory(int(sys.argv[1]))



def M3U(fichier):
    mon_fichier = open(fichier, "r")
    contenu=mon_fichier.read().split('\n')
    chaines=Trier(contenu)
    TRAITEMENT(chaines)

def IPTV(url):
    try:
        m3u = getHtml(url)
        parsem3u(m3u)
    except:
        addDir('Nothing found', '', '', '', Folder=False)
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def parsem3u(html, sitechk=True):
    match = re.compile('#.+,(.+?)\n(.+?)\n').findall(html)
    txtfilter = txtfilter = GETFILTER()
    txtfilter = txtfilter.split(',') if txtfilter else []
    txtfilter = [f.lower().strip() for f in txtfilter]
    i = 0
    count = 0
    for name, url in match:
        status = ""
        url = url.replace('\r','')
        if not txtfilter or any(f in name.lower() for f in txtfilter):
            if sitechk:
                if i < 5:
                    try:
                        siteup = urllib.request.urlopen(url).getcode()
                        status = " [COLOR red]offline[/COLOR]" if siteup != 200 else " [COLOR green]online[/COLOR]"
                    except: status = " [COLOR red]offline[/COLOR]"
                    i += 1
            addPlayLink(name+status, url, 3, icon, '')
            count += 1
    return count

def PLAY(url, title):
    logg('url',url)
    playmode = int(addon.getSetting('playmode'))
    iconimage = xbmc.getInfoImage("ListItem.Thumb")
    if playmode == 0:
        stype = ''
        if '.ts' in url :
            stype = 'TSDOWNLOADER'
        elif '.m3u' in url:
            stype = 'HLSRETRY'
        if stype:
            from F4mProxy import f4mProxyHelper
            f4mp=f4mProxyHelper()
            skin_used = xbmc.getSkinDir()
            if skin_used == 'skin.estuary':
                xbmc.executebuiltin('Container.SetViewMode(500)') # "Thumbnail" view
            xbmcplugin.endOfDirectory(int(sys.argv[1]), cacheToDisc=False)
            f4mp.playF4mLink(url,name,proxy=None,use_proxy_for_chunks=False, maxbitrate=0, simpleDownloader=False, auth=None, streamtype=stype,setResolved=False,swf=None , callbackpath="",callbackparam="", iconImage=iconimage)
            return
    
    listitem = xbmcgui.ListItem(name)
    #, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
    listitem.setInfo('video', {'Title': name})
    listitem.setProperty("IsPlayable","true")
    xbmc.Player().play(url, listitem)

def getParams():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if params[len(params) - 1] == '/':
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param
def INIT():
    MAIN()

params = getParams()
url = None
name = None
mode = None
img = None

serveur=''
try: url = urllib.parse.unquote_plus(params["url"])
except: pass
try: name = urllib.parse.unquote_plus(params["name"])
except: pass
try: mode = int(params["mode"])
except: pass
try: img = urllib.parse.unquote_plus(params["img"])
except: pass

if mode is None: INIT()
elif mode == 0: MAIN(url)
elif mode == 2: IPTV(url)
elif mode == 3: PLAY(url, name)
elif mode == 4: emu_mag(url, name)
elif mode == 5: OPENSETTINGS()
elif mode == 6: run(url, name)
elif mode == 7: run_vod(url, name)
elif mode == 8: run_serie(url, name)
elif mode == 9: run_replay(url, name)
elif mode == 41: M3U(url)
elif mode == 1000: emu_mag(url,'')
