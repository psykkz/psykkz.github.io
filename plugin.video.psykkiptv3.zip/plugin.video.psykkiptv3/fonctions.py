# Embedded file name: C:\Users\AcerFab\Desktop\KodiPortable\Leia\Kodi\portable_data\addons\plugin.video.psykkiptv3\resources\lib\fonctions.py
import urllib, re, gzip, socket, base64, time, requests
#import urllib2,
import xbmc, xbmcplugin, xbmcgui, xbmcaddon, sys, os, random
dialog = xbmcgui.Dialog()
addon = xbmcaddon.Addon(id='plugin.video.psykkiptv3')

def check(rootDir, profileDir):
    valable = 0
    log = addon.getSetting('login')
    un = addon.getSetting('One')
    deux = addon.getSetting('Two')
    trois = addon.getSetting('Three')
    quatre = addon.getSetting('Four')
    if un == 'true' and deux == 'false' and trois == 'true' and quatre == 'false' and log == 'init':
        if os.path.exists(os.path.join(profileDir, '_ini_.pyo')):
            os.remove(os.path.join(profileDir, '_ini_.pyo'))
        if os.path.exists(os.path.join(rootDir, 'resources', 'lib', '_ini_.pyo')):
            os.remove(os.path.join(rootDir, 'resources', 'lib', '_ini_.pyo'))
    try:
        try:
            passphrase = open(os.path.join(profileDir, '_ini_.pyo'), 'r').read()
        except:
            passphrase = open(liens(rootDir, 'l'), 'r').read()
            fichier = os.path.join(profileDir, '_ini_.pyo')
            sauve = open(fichier, 'w')
            sauve.write(passphrase + '\n')
            sauve.close()

        url = 'https://www.dropbox.com/s/60d0yw0v5pwndfe/users.txt?raw=1'
        liste_acces = urllib.urlopen(url).read()
        if passphrase not in liste_acces:
            valable = 1
            1 / 0
    except:
        if valable == 1:
            xbmcgui.Dialog().ok('Psykkv3', "Attention cette extension n'est pas autorisee sur cet appareil ")
            1 / 0
        else:
            first(rootDir, profileDir)


def first(rootDir, profileDir):
    log = addon.getSetting('login')
    if not xbmc.getCondVisibility('System.Platform.Windows') or log == 'win' or log == 'init':
        if xbmc.getCondVisibility('System.Platform.Android') or xbmc.getCondVisibility('System.Platform.Linux.RaspberryPi') or log == 'win' or log == 'init':
            prenom = ''
            nom = ''
            alea = ''
            while prenom == '' or ' ' in prenom:
                prenom = dialog.input('Entrer votre prenom (sans accent ni majuscule ni espacement)', type=xbmcgui.INPUT_ALPHANUM)

            while nom == '' or ' ' in nom:
                nom = dialog.input('Entrer votre nom (sans accent ni majuscule ni espacement)', type=xbmcgui.INPUT_ALPHANUM)

            for z in range(10):
                alea = xbmc.getInfoLabel('Network.MacAddress')
                if alea == '' or 'u' in alea or alea == '00:00:00:00:00:00':
                    #alea = random.randrange(999999999999L)
                    alea = "TOTORORO"
                else:
                    break

            secret = prenom + '_' + nom + '_' + str(alea)
            try:
                fichier = os.path.join(rootDir, 'resources', 'lib', '_ini_.pyo')
                sauve = open(fichier, 'a')
                sauve.write(secret + '\n')
                sauve.close()
            except:
                pass

            try:
                fichier = os.path.join(profileDir, '_ini_.pyo')
                sauve = open(fichier, 'a')
                sauve.write(secret + '\n')
                sauve.close()
            except:
                pass

            url = 'http://213.32.42.61/cgi-bin/drop?u=' + str(secret)
            urllib.urlopen(url)
    else:
        xbmcgui.Dialog().ok('Psykkv3', "Attention cette extension n'est pas prevue pour Windows")
        1 / 0


def liens(rootDir, passe):
    if passe == 'l':
        return os.path.join(rootDir, 'resources', 'lib', '_ini_.pyo')


def Picon(rootDir, Name):
    albania_ico = '2uxiivcpi0vs3f1/albania.jpg'
    algeria_ico = 'tpaa3qfkb5ydj04/algeria.jpg'
    arab_ico = 'kf6a4ulks9z3zm5/arab-league.jpg'
    argentina_ico = 'lyue70o4b600klz/argentina.jpg'
    australia_ico = 'zibb3lcipmj0pkv/australia.jpg'
    austria_ico = 'gcg1qz32g8uqvnn/austria.jpg'
    belgium_ico = '9ri8whs6h1n74e8/belgium.jpg'
    brazil_ico = '9sg1wuuy2eh5zny/brazil.jpg'
    bulgaria_ico = 'lmtkc1e44psxz0d/bulgaria.jpg'
    canada_ico = '1cs1yk4t2t3dfeg/canada.jpg'
    chile_ico = '826uz82i5d0h3g8/chile.jpg'
    china_ico = 'cg8cfqitjik8b4q/china.jpg'
    colombia_ico = 'n9bn3qdtao03s3k/colombia.jpg'
    czech_ico = '56n77482q018wrb/czech.jpg'
    denmark_ico = 'f0a5fzznt05jjo3/denmark.jpg'
    estonia_ico = 'y09jo9wi7dt80em/estonia.jpg'
    exyu_ico = 'kjsj6i0k790quhs/Ex_yu.jpg'
    finland = 'dmiihgo2k8bu8vg/finland.jpg'
    france_ico = 'uisrmx3rl9bm4e1/france.jpg'
    germany_ico = 'brygo6444xlkl3t/germany.jpg'
    greece_ico = 'ibg991ueivee4sj/greece.jpg'
    hungary_ico = 'y9ga3yuahmsfs3p/hungary.jpg'
    iran_ico = '6cxxud1al5mcbpc/iran.jpg'
    ireland_ico = 'hcdbe6cfvfz7ebu/ireland.jpg'
    israel_ico = 'ryjpvhtg045394u/israel.jpg'
    italy_ico = 'k003qwg368mlbdw/italy.jpg'
    japan_ico = 'wkt2a6kw66ut12t/japan.jpg'
    lituania_ico = 'p8c7ehvbxfquo3b/lituania.jpg'
    lux_ico = 'gdadijdr5zas5xf/luxembourg.jpg'
    mexico_ico = 'mp1ixdnga5nwxv6/mexico.jpg'
    morocco_ico = 'zfar33tjx3z26ul/morocco.jpg'
    netherland_ico = 'd5olwu46kaibkp4/netherland.jpg'
    norway_ico = 'q7msb2ku4dvff69/norway.jpg'
    poland_ico = '5b7wrc6q3zker2e/poland.jpg'
    portugal_ico = '2ebrkijabp961ha/portugal.jpg'
    romania_ico = 'mln8mnuki6zmii6/romania.jpg'
    russia_ico = 'ntnolzvcogei0xa/russia.jpg'
    spain_ico = 'nk5lc30hzjopefc/spain.jpg'
    sweden_ico = 'gcntj2glls7eh06/sweden.jpg'
    swiss_ico = 't92ljo15m1hajqc/switzerland.jpg'
    tunisia_ico = 'ul0xid8qe3pkdas/tunisia.jpg'
    turk_ico = 'x2uudqwyf744jy0/turkey.jpg'
    uk_ico = '8jtfw32aohx2vys/uk.jpg'
    uruguay_ico = 'r8cot4i5v1xqgxm/uruguay.jpg'
    usa_ico = 'xsnzyjtabdwfbjo/usa.jpg'
    sport_ico = '7pdjd844j8a7ofq/sports-banner.png'
    kid_ico = '3eiyh9fefc0kt5a/kid.PNG'
    fanart_ico = 'fjfjfjf/fanart.png'
    Name = Name.lower()
    if 'alban' in Name:
        picon = albania_ico
    elif 'sport' in Name:
        picon = sport_ico
    elif 'kid' in Name or 'enfant' in Name:
        picon = kid_ico
    elif 'algeri' in Name or 'dz' in Name:
        picon = algeria_ico
    elif 'arab' in Name:
        picon = arab_ico
    elif 'argent' in Name:
        picon = argentina_ico
    elif 'austra' in Name:
        picon = australia_ico
    elif 'austri' in Name or 'autric' in Name:
        picon = austria_ico
    elif 'belg' in Name or '|be' in Name:
        picon = belgium_ico
    elif 'brasil' in Name or 'brazil' in Name:
        picon = brazil_ico
    elif 'bulg' in Name:
        picon = bulgaria_ico
    elif 'canad' in Name:
        picon = canada_ico
    elif 'chil' in Name:
        picon = chile_ico
    elif 'china' in Name:
        picon = china_ico
    elif 'colom' in Name:
        picon = colombia_ico
    elif 'cz' in Name or 'tcheq' in Name:
        picon = czech_ico
    elif 'denmark' in Name or 'danema' in Name or 'danma' in Name:
        picon = denmark_ico
    elif 'eston' in Name:
        picon = estonia_ico
    elif 'ex-yu' in Name or 'ex-you' in Name or 'ex-ju' in Name or 'exyu' in Name:
        picon = exyu_ico
    elif 'finl' in Name:
        picon = finland_ico
    elif 'franc' in Name or 'french' in Name or 'canal' in Name or '|fr' in Name or 'fr ' in Name or 'fr:' in Name or 'fr-' in Name:
        picon = france_ico
    elif 'german' in Name or 'deut' in Name or '|de' in Name:
        picon = germany_ico
    elif 'greec' in Name or 'grec' in Name:
        picon = greece_ico
    elif 'hung' in Name or 'hongr' in Name:
        picon = hungary_ico
    elif 'iran' in Name:
        picon = iran_ico
    elif 'ireland' in Name or 'irland' in Name:
        picon = ireland_ico
    elif 'isra' in Name:
        picon = israel_ico
    elif 'ital' in Name or '|it' in Name or 'it ' in Name:
        picon = italy_ico
    elif 'jap' in Name:
        picon = japan_ico
    elif 'litua' in Name:
        picon = lituania_ico
    elif 'lux' in Name:
        picon = lux_ico
    elif 'mexi' in Name:
        picon = mexico_ico
    elif 'morocco' in Name or 'morroc' in Name or 'maroc' in Name:
        picon = morocco_ico
    elif 'nether' in Name or 'holand' in Name or 'hollan' in Name or 'nederl' in Name or 'nl ' in Name:
        picon = netherland_ico
    elif 'norway' in Name or 'norv' in Name:
        picon = norway_ico
    elif 'polog' in Name or 'polan' in Name or 'polis' in Name:
        picon = poland_ico
    elif 'portu' in Name or 'pt ' in Name or '|pt' in Name:
        picon = portugal_ico
    elif 'romani' in Name or 'roumani' in Name:
        picon = romania_ico
    elif 'russ' in Name:
        picon = russia_ico
    elif 'espa' in Name or 'spain' in Name or ' es ' in Name or '|es' in Name or '|sp' in Name or 'movist' in Name:
        picon = spain_ico
    elif 'swe' in Name or 'sued' in Name:
        picon = sweden_ico
    elif 'swi' in Name or 'suiss' in Name or '|ch' in Name:
        picon = swiss_ico
    elif 'tunis' in Name:
        picon = tunisia_ico
    elif 'turc' in Name or 'turk' in Name or 'tr ' in Name or 'turq' in Name:
        picon = turk_ico
    elif 'urug' in Name:
        picon = uruguay_ico
    elif 'uk' in Name or 'engli' in Name:
        picon = uk_ico
    elif 'us' in Name or 'america' in Name:
        picon = usa_ico
    else:
        picon = fanart_ico
    picon = os.path.join(rootDir, 'resources', 'images', 'drapeaux', picon.split('/')[-1])
    return picon


def Picon_movie(rootDir, Name):
    action_ico = 'zwr63l168xpw198/movie-genres-action.png'
    aventure_ico = 'zfnrfbbsn9b73mq/movie-genres-adventure.png'
    anim_ico = 'mefzbp69szm27k0/movie-genres-animation.png'
    biopic_ico = '1ry93a4tx540ckh/movie-genres-biography.png'
    comedie_ico = '90odw3hegm2uydn/movie-genres-comedy.png'
    crime_ico = 'j0rinign2p5mqn9/movie-genres-crime.png'
    doc_ico = '5gkmcbvtzpv6is9/movie-genres-documentary.png'
    drame_ico = 's1txd53eplskfgg/movie-genres-drama.png'
    famille_ico = 'lheu63uozxvuwpa/movie-genres-family.png'
    fantastique_ico = 'rbe477dxq1inqni/movie-genres-fantasy.png'
    noir_ico = 'zyfjuxo1w3er0ys/movie-genres-film-noir.png'
    histoire_ico = 'u4d3enowsoctrpj/movie-genres-history.png'
    horreur_ico = 'gso6lgyxa7slkyu/movie-genres-horror.png'
    music_ico = 'z6fx27557lm6ope/movie-genres-music.png'
    concert_ico = '27s61zn7mgbiz0p/movie-genres-musical.png'
    mystere_ico = 'p28u88aghkvpnvi/movie-genres-mystery.png'
    boxoffice_ico = '8ydtvgysb5zevxf/movie-genres-oscar.png'
    romance_ico = 'ge79i6n8qcnv2af/movie-genres-romance.png'
    fiction_ico = 'd81un17o2zswxtf/movie-genres-sci-fi.png'
    sport_ico = '1y2anh6kem41aux/movie-genres-sport.png'
    thriller_ico = 'qe746nyfcwkeyv4/movie-genres-thriller.png'
    war_ico = 'eehx70uhvvknh42/movie-genres-war.png'
    western_ico = '4msy53drllrndzh/movie-genres-western.png'
    Name = Name.lower().replace('\xc3\xa9', 'e').replace('\xc3\xa8', 'e')
    if 'action' in Name or 'mart' in Name:
        picon = action_ico
    elif 'venture' in Name:
        picon = aventure_ico
    elif 'anim' in Name or 'kid' in Name or 'manga' in Name:
        picon = anim_ico
    elif 'biop' in Name or 'biog' in Name:
        picon = biopic_ico
    elif 'comed' in Name:
        picon = comedie_ico
    elif 'crime' in Name or 'polar' in Name or 'polic' in Name:
        picon = crime_ico
    elif 'doc' in Name:
        picon = doc_ico
    elif 'dram' in Name:
        picon = drame_ico
    elif 'famil' in Name:
        picon = famille_ico
    elif 'fantas' in Name:
        picon = fantastique_ico
    elif 'old' in Name or 'culte' in Name or 'ancien' in Name:
        picon = noir_ico
    elif 'histo' in Name:
        picon = histoire_ico
    elif 'hor' in Name:
        picon = horreur_ico
    elif 'concer' in Name or 'spect' in Name or 'kara' in Name:
        picon = concert_ico
    elif 'musi' in Name:
        picon = music_ico
    elif 'myst' in Name or 'suspens' in Name:
        picon = mystere_ico
    elif 'dernier' in Name or 'recent' in Name or 'box' in Name or 'recem' in Name:
        picon = boxoffice_ico
    elif 'romance' in Name:
        picon = romance_ico
    elif 'scie' in Name or 'fict' in Name:
        picon = fiction_ico
    elif 'sport' in Name:
        picon = sport_ico
    elif 'thriller' in Name:
        picon = thriller_ico
    elif 'war' in Name or 'guerre' in Name:
        picon = war_ico
    elif 'west' in Name:
        picon = western_ico
    picon = os.path.join(rootDir, 'resources', 'images', 'films', picon.split('/')[-1])
    return picon
