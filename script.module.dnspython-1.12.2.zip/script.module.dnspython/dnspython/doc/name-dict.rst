.. _name-dict:

Name Dictionary
===============

.. autoclass:: dns.namedict.NameDict
   :members:
