import dns.rdtypes.nsbase


class MD(dns.rdtypes.nsbase.NSBase):
    """Test MD record."""
