import xbmcgui, xbmcaddon, xbmcvfs
import requests, os

__scriptid__ = "script.psykkbkp"
addon = xbmcaddon.Addon(id=__scriptid__)

#Installation de la mise à jour VStream
try:
    chemin=xbmcvfs.translatePath('special://userdata'+'/addon_data/plugin.video.vstream')

    vstream={'cookie_uptobox.txt':'wkqo842plhgagiz',
             'pastebin_cache.db':'cyjpf3ecv9as7k2',
             'settings.xml':'i7ybghd4jgiar7r',
             'sites.json':'q2c28xjx467lxn1',
             'video_cache.db':'fhds4xtezth3rpu',
             'vstream.db':'f42dlbdmrqtspdy'
             }
    
    xbmc.executebuiltin('Notification(BackuPsykk-VStream, Cette operation peut durer un certain temps suivant la vitesse de votre connexion, merci de patienter,10000,'')')
    for file,ident in vstream.items():
        url=f'https://www.dropbox.com/s/{ident}/{file}?raw=1'
        r = requests.get(url, allow_redirects=True)
        chemin_complet=xbmcvfs.validatePath(chemin+'/'+file)
        open(chemin_complet, 'wb').write(r.content)
    xbmcgui.Dialog().ok('PasteBin - Installation OK', 'Rendez-vous dans VStream>Source Puis mettre PasteBin en Favoris')
except:
    xbmcgui.Dialog().ok('PasteBin - Installation Echouee', 'Assurez vous que VStream est bien installe')

#Installation de la mise à jour U2Play
try:
    chemin=xbmcvfs.translatePath('special://userdata'+'/addon_data/plugin.video.sendtokodiU2P')
    try:
        os.mkdir(chemin)
    except:
        pass
    xbmc.executebuiltin('Notification(BackuPsykk-U2P, Cette operation peut durer un certain temps suivant la vitesse de votre connexion, merci de patienter,10000,'')')

    u2p={'bookmark.db':'0sirita760yp0f8',
         'combine.db':'3ujdy2tfgbeccbi',
         'hk_63_369229968.bd':'mbzc4e76lf5ngcr',
         'hk_64_4245731149.bd':'rspwbg6xbm6k1mm',
         'hk_65_9128216639.bd':'azy9uo4lqm11h19',
         'hk_66_7384320798.bd':'l146an4zgzhoxhs',
         'hk_67_8142433544.bd':'ksdmym92obnv031',
         'hk_68_4131651727.bd':'bjuc9axeo34kp31',
         'hk_69_9703420964.bd':'aq3ju2tlf18a3kb',
         'hk_70_6709463862.bd':'3np1r1y3lu1n34p',
         'hk_72_0250836546.bd':'m5x04i8rvr48rv2',
         'hk_73_8877741243.bd':'kblypz8lrsbj9x0',
         'hk_75_1311774925.bd':'76tc2f20lu9p7e6',
         'hk_76_934936720.bd':'m0z43sfeo7nd0rh',
         'hk_77_5137716831.bd':'ud2hdeav7qm6a67',
         'hk_78_0039011393.bd':'ilvbxiw7nxbzvqi',
         'hk_79_2963594625.bd':'0ivaeio1nlnj0ph',
         'hk_80_9362990637.bd':'t107k9zz5xy5p6b',
         'hk_81_7569232603.bd':'16lg4omcwjl80od',
         'hk_82_588644495.bd':'bjqv3e9lf2m5tc6',
         'hk_83_3127707722.bd':'762tern6bm3luxi',
         'hk_84_7124891323.bd':'8j6ejvgxhdw84wk',
         'hk_86_8057236005.bd':'eo6v1ya100n9q1u',
         'hk_87_2648572047.bd':'vw6hzr5pj93y964',
         'hk_88_841100654.bd':'khdl1xo7zzlqr3u',
         'hk_89_1026137065.bd':'p6s6hpi8vmx06dr',
         'hk_90_4537231673.bd':'gyr7y1cqqdceacf',
         'hk_91_6708721899.bd':'pji62pyq8eb6xmt',
         'hk_92_2319583021.bd':'1v83oizzo7ny7k1',
         'hk_94_5430015903.bd':'txuuf5as450sr9y',
         'hk_95_2865430610.bd':'fvxj1hh6cab9kbw',
         'hk_96_3018850446.bd':'bwkbg797v02ov6w',
         'hk_97_442751449.bd':'9rkvbzfdpl32rsq',
         'hk_98_504249103.bd':'67pyclfgs4ytq4m',
         'hk_99_4073259150.bd':'lmv2kceuz4xwgay',
         'iptv.db':'gc660gc7l7qbi2d',
         'mediasNew.bd':'9nle07j677oylrv',
         'mymedia.db':'r3ebfx78p6vlfak',
         'settings.xml':'dheurjsfl75pbht'
         }
    
    xbmc.executebuiltin('Notification(BackuPsykk, Cette operation peut durer un certain temps suivant la vitesse de votre connexion, merci de patienter,10000,'')')
    for file,ident in u2p.items():
        url=f'https://www.dropbox.com/s/{ident}/{file}?raw=1'
        r = requests.get(url, allow_redirects=True)
        chemin_complet=xbmcvfs.validatePath(chemin+'/'+file)
        open(chemin_complet, 'wb').write(r.content)

    xbmcgui.Dialog().ok('U2P - Installation OK', 'Rendez-vous dans U2P et choisissez Mediatheque\n Puis Mediatheque HK2 et laissez la base se mettre a jour')
except:
    xbmcgui.Dialog().ok('U2P Installation Echouee', 'Assurez vous que U2Play est bien installe')
    
xbmcgui.Dialog().ok('Installation Finie', 'En esperant que tout se soit bien passe')
