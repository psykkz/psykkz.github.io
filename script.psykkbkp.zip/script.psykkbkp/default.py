import xbmcgui, xbmcaddon, xbmcvfs
import requests, os

__scriptid__ = "script.psykkbkp"
addon = xbmcaddon.Addon(id=__scriptid__)

url='https://psykkz.github.io/zip/save_kod/'
r = requests.get(url, allow_redirects=True)
dossiers=r.text.split('a href="')
rep=[]
for dossier in dossiers:
    #print(dossier)
    if '">/' in dossier:
        d=dossier.split('">/')[1]
        #print(d)
        if '/'in d:
            rep.append(d.split('/')[0])
            
#Installation des fichiers dans les differents dossiers
for dossier in rep:
    chemin=xbmcvfs.translatePath('special://userdata'+f'/addon_data/{dossier}')
    if not(os.path.exists(chemin)):
        os.mkdir(chemin)
    xbmc.executebuiltin(f'Notification(BackuPsykk-{dossier}, Cette operation peut durer un certain temps suivant la vitesse de votre connexion, merci de patienter,10000,'')')
    recup_fichier=url+f'{dossier}/index.html'
    r = requests.get(recup_fichier, allow_redirects=True)
    contenu=(r.content)
    contenu=str(contenu).split('a href="')[1:]
    for fichier in contenu:
        adresse_fichier=f"""{url}/{dossier}/{fichier.split('"')[0]}"""
        r = requests.get(adresse_fichier, allow_redirects=True)
        chemin_complet=xbmcvfs.validatePath(chemin+'/'+fichier.split('"')[0])
        open(chemin_complet, 'wb').write(r.content)
    xbmcgui.Dialog().ok(f'{dossier} - Installation OK', 'hey')
 
xbmcgui.Dialog().ok('Installation Finie', 'En esperant que tout se soit bien passe')
